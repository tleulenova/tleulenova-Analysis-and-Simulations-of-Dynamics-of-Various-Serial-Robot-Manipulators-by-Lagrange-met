close all;
T1 = [1.824 1.793 1.714 1.56 1.304];
time = [1 2 3 4 5];

plot(T1,time);